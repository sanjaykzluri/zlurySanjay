import React from 'react'


export const DepartmentsTable = () => {
    return (
        <>
            <h1> First table  </h1>
        </>
    )
}