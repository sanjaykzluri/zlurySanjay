
import React from "react";
import "./Tabs.scss";
import { TabNavItem } from "./TabNavItem";
import { SearchIcon } from './assets/SearchIcon'

export function Tabs() {
    return (
        // <ul className="nav nav-tabs">
        //     <TabNavItem
        //         className="recognisedSpellChange"
        //         hash="#departments"
        //         text="Departments"
        //     />
        //     <TabNavItem
        //         className="unrecognisedSpellChange"
        //         hash="#cost-centres"
        //         text="Cost Centres"
        //     />
        //     <TabNavItem hash="#business-units" text="Business Unites" />
        //     <TabNavItem hash="#locations" text="Locations" />

        // </ul>
        <>
            <div className="tabs-container">
                <div className="tabs-heading"> Chargebacks </div>
                <div className="tabs">
                    <button className="active-tab"> Departments</button>
                    <button> Cost Centres</button>
                    <button> Business Unit </button>
                    <button> Locations </button>
                </div>
                <div className="icons">
                    <div className="search-icon">
                        <img src={SearchIcon} alt="search" />
                    </div>

                    <div className="other-icon">
                        <img src="./icons/Icon_Notification_Default.svg" />
                        <img src="./icons/Icon_Notification_Default.svg" />
                        <img src="./icons/Icon_Notification_Default.svg" />

                    </div>
                </div>

            </div>
        </>
    );
}


/* 


import React from "react";
import "./Tabs.scss";
import { TabNavItem } from "./TabNavItem";

export function Tabs() {
    return (
        <ul className="nav nav-tabs">
            <TabNavItem
                className="recognisedSpellChange"
                hash="#recognised"
                text="Recognised"
            />
            <TabNavItem
                className="unrecognisedSpellChange"
                hash="#unrecognised"
                text="Unrecognised"
            />
            <TabNavItem hash="#archived" text="Archived" />
            <TabNavItem hash="#payment-methods" text="Payment Methods" />
            <TabNavItem hash="#uploads" text="Uploads" />
        </ul>
    );
}

*/ 